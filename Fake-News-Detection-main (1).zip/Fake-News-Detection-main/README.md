# Fake-News-Detection
Nowadays, fake news has become a common trend. Even trusted media houses are known to spread fake news and are losing their credibility. So, how can we trust any news to be real or fake?
In this project, I have built a classifier model that can identify news as real or fake. For this purpose, I have used data from drive, but you can use any data to build this model following the same methods.
With the help of this project you can create an NLP classifier to detect whether the news is real or fake.
